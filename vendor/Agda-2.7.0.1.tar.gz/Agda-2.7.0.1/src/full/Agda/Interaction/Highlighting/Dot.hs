{-# OPTIONS_GHC -Wunused-imports #-}

module Agda.Interaction.Highlighting.Dot
  ( dotBackend
  ) where

import Agda.Interaction.Highlighting.Dot.Backend ( dotBackend )
